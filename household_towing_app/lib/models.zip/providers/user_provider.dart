import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/user_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserProvider with ChangeNotifier {
  final UserService _userService;
  final FirebaseAuth _firebaseAuth;

  Map<String, dynamic>? _userProfile;
  Map<String, dynamic>? _providerProfile;
  Map<String, dynamic>? _driverProfile;
  bool _isLoading = true;
  String? _role;
  bool _isDarkMode = false;
  String? _errorMessage;

  UserProvider({UserService? userService, FirebaseAuth? firebaseAuth}) 
      : _userService = userService ?? UserService(),
        _firebaseAuth = firebaseAuth ?? FirebaseAuth.instance {
    _loadTheme();
  }

  Map<String, dynamic>? get userProfile => _userProfile;
  Map<String, dynamic>? get providerProfile => _providerProfile;
  Map<String, dynamic>? get driverProfile => _driverProfile;
  bool get isLoading => _isLoading;
  String? get role => _role;
  bool get isDarkMode => _isDarkMode;
  String? get errorMessage => _errorMessage;

  bool get isProvider => _role?.toLowerCase() == 'provider';
  bool get isAdmin => _role?.toLowerCase() == 'admin';
  bool get isDriver => _role?.toLowerCase() == 'driver';
  String get uid => _firebaseAuth.currentUser?.uid ?? "";

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('isDarkMode') ?? false;
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', _isDarkMode);
    notifyListeners();
  }

  /// Load current user profile and role
  Future<void> loadCurrentUserData() async {
    final user = _firebaseAuth.currentUser;
    if (user == null) {
      _userProfile = null;
      _providerProfile = null;
      _driverProfile = null;
      _role = null;
      _isLoading = false;
      notifyListeners();
      return;
    }

    _isLoading = true;
    notifyListeners();

    try {
      _errorMessage = null;
      // Get role and base profile from 'users'
      final profile = await _userService.getUserProfile(user.uid);
      if (profile != null) {
        _userProfile = profile;
        _role = profile['role'];

        // If provider or pending provider, also fetch provider-specific data
        if (_role == 'provider' || _role == 'pending_provider') {
          _providerProfile = await _userService.getProviderProfile(user.uid);
          // Backfill invite code if missing (for providers registered before this feature)
          if (_providerProfile != null && (_providerProfile!['inviteCode'] == null || (_providerProfile!['inviteCode'] as String).isEmpty)) {
            final generatedCode = user.uid.substring(0, 6).toUpperCase();
            await FirebaseFirestore.instance.collection('providers').doc(user.uid).update({'inviteCode': generatedCode});
            _providerProfile!['inviteCode'] = generatedCode;
          }
        } else if (_role == 'driver') {
          _driverProfile = await _userService.getDriverProfile(user.uid);
        }
      } else {
        _errorMessage = "User profile not found";
      }
    } catch (e) {
      _errorMessage = "Failed to load user data: $e";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Update availability (optimistic UI update)
  Future<void> toggleAvailability(bool value) async {
    if (_providerProfile == null) return;

    final previousValue = _providerProfile!['isAvailable'] ?? true;
    _providerProfile!['isAvailable'] = value;
    notifyListeners();

    try {
      final user = _firebaseAuth.currentUser;
      if (user != null) {
        await _userService.updateProviderAvailability(user.uid, value);
      }
    } catch (e) {
      // Revert on error
      _providerProfile!['isAvailable'] = previousValue;
      notifyListeners();
      rethrow;
    }
  }

  /// Clear data on logout
  void clear() {
    _userProfile = null;
    _providerProfile = null;
    _driverProfile = null;
    _role = null;
    _isLoading = true;
    notifyListeners();
  }
}
